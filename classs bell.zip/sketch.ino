#include <WiFi.h>
#include <PubSubClient.h>
#include <time.h>

// WiFi details
const char* WIFI_SSID = "Wokwi-GUEST";
const char* WIFI_PASS = "";

// MQTT details
const char* BROKER = "ssse/w4/naziya987/cmd";
const int MQTT_PORT = 1883;

WiFiClient espClient;
PubSubClient client(espClient);

// Buzzer pin
const int BUZZER_PIN = 18;

// Bell duration
const int BELL_TIME = 5000;

// Bell schedule (24-hour format)
struct BellSchedule {
  int hour;
  int minute;
  const char* event;
};

BellSchedule schedule[] = {
  {10, 30, "Morning Break"},
  {10, 45, "Break End"},
  {13, 0, "Lunch Start"},
  {13, 40, "Lunch End"},
  {16, 0, "College End"}
};

const int totalEvents = sizeof(schedule) / sizeof(schedule[0]);

int lastTriggeredDay[5] = {-1, -1, -1, -1, -1};

void connectWiFi() {
  WiFi.begin(WIFI_SSID, WIFI_PASS);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
  }

  Serial.println("WiFi Connected");
}

void connectMQTT() {
  while (!client.connected()) {
    if (client.connect("ESP32CollegeBell")) {
      Serial.println("MQTT Connected");
    } else {
      delay(2000);
    }
  }
}

void ringBell(const char* event) {
  Serial.print("Bell ringing: ");
  Serial.println(event);

  digitalWrite(BUZZER_PIN, HIGH);

  if (client.connected()) {
    client.publish("college/bell", event);
  }

  delay(BELL_TIME);

  digitalWrite(BUZZER_PIN, LOW);
}

void setup() {
  Serial.begin(115200);

  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  connectWiFi();

  client.setServer(BROKER, MQTT_PORT);

  configTime(19800, 0,
             "pool.ntp.org",
             "time.google.com");

  Serial.println("Automatic College Bell System Started");
}

void loop() {
  if (!client.connected()) {
    connectMQTT();
  }

  client.loop();

  struct tm timeInfo;

  if (!getLocalTime(&timeInfo, 1000)) {
    Serial.println("Waiting for time...");
    return;
  }

  for (int i = 0; i < totalEvents; i++) {

    if (timeInfo.tm_hour == schedule[i].hour &&
        timeInfo.tm_min == schedule[i].minute &&
        lastTriggeredDay[i] != timeInfo.tm_yday) {

      lastTriggeredDay[i] = timeInfo.tm_yday;

      ringBell(schedule[i].event);
    }
  }

  delay(1000);
}